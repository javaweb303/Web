package org.pub.dao;

import java.util.List;

import org.pub.vo.GongjiVO;

public interface PubDAO {

	List<GongjiVO> getList();


}
