package org.pub.service;

import java.util.List;

import org.pub.vo.GongjiVO;

public interface PubService {

	List<GongjiVO> getList();


}
