package org.pub.vo;

import lombok.Data;

@Data
public class FaqCategoryVO {

	private int categoryId;
	private String categoryName;
}
