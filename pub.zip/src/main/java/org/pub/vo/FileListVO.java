package org.pub.vo;

import lombok.Data;

@Data
public class FileListVO {
	private int file_no;
	private String boardcd;
	private int e_no;
}
